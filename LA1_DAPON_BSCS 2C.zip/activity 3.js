//BOOLEAN
let jsProgrammingLanguage = true;
let jsHard = false;
let favNumb = 17;

console.log(jsProgrammingLanguage);
console.log(jsHard);
console.log(favNumb+undefined);
