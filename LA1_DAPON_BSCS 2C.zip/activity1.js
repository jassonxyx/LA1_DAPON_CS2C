//VARIABLES
var name = "Mark Jasson Dapon"
var whatDoYouWannaBecomeInYourLife = "Programmer";
var gender = "Male";
var facebookAcct = "Ya Jie";
console.log(name)
console.log(whatDoYouWannaBecomeInYourLife);
console.log(gender);
console.log(facebookAcct);