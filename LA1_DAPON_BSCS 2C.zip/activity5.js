//STRINGS
let favActorFirstName = "Felix ";
let favActorLastName = "Cha";
let fullName = favActorFirstName + " " + favActorLastName;
let changeCaps = fullName.toUpperCase();
let message = "My favorite actor is ";
let message2 = "  his best show is True Beauty";
console.log(message + fullName.toUpperCase() + message2);